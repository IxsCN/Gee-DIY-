module("luci.controller.app.backgroud", package.seeall)

function index()
	local page   = node("app", "backgroud")
	page.target  = firstchild()
	page.title   = _("")
	page.order   = 10
    	page.sysauth = "admin"
      	page.mediaurlbase = "/turbo-static/turbo/web"
        local superkey = (luci.http.getcookie("superkey"))
 	if superkey ~= nil then
       		page.sysauth_authenticator = "appauth"
	else
        	page.sysauth_authenticator = "htmlauth_web"
        end	
	page.index = true
	
	entry({"app"}, firstchild(), _(""), 700)
	entry({"app", "backgroud"}, template("app/backgroud"), _("status"), 700 ,true)
end