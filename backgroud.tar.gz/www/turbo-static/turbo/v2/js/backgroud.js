$.ajax({
    'url': '/cgi-bin/turbo/app/backgroud',
    'dataType': 'html',
    'success': function (data) {
        $("body").css("transition","background 1.5s linear").css("background-image","url(" + data + ")");
    }
});